import typing as T

_EYE_RADIUS_DEFAULT: float = 10.392304845413264
DEFAULT_SPHERE_CENTER: T.Tuple[float, float, float] = (0.0, 0.0, 35.0)
